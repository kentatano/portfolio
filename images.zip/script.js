
document.addEventListener("DOMContentLoaded", function() {
    setTimeout(function() {
        document.getElementById("splash").style.display = "none";
    }, 3000);
});
